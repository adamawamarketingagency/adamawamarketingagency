# Adamawa Real Estate Marketer

A simple React + Tailwind landing page (one-page + multi-section versions) for Adamawa Real Estate Marketer.

## Quick start (local preview)

1. Install Node.js (v16+ recommended).
2. In the project folder run:

```bash
npm install
npm run dev
```

3. Open the local dev server shown by Vite (e.g. http://localhost:5173).

> This project uses Tailwind via CDN in `index.html` for fast preview. To use integrated Tailwind properly, follow the Tailwind + Vite setup and add `index.css` + config.

## Enabling working contact form (Formspree)

1. Go to https://formspree.io and create a free form.
2. Copy your form endpoint (looks like: https://formspree.io/f/xxxxx).
3. In `src/App.jsx` replace `FORMSPREE_ENDPOINT` with your endpoint (keep quotes).
4. Rebuild and re-deploy.

## Deploying to Vercel

1. Create a GitHub repo and push this project.
2. Sign up at https://vercel.com and choose "Import Project" -> select your GitHub repo.
3. Vercel usually auto-detects Vite. If prompted, set:
   - Build Command: `npm run build`
   - Output Directory: `dist`
4. Add any environment variables (not required for default preview). If you use a server-side form, set the endpoint in code or environment.
5. Deploy.

## Deploying to Netlify

1. Create a GitHub repo and push this project.
2. Sign up at https://app.netlify.com and click "New site from Git".
3. Connect your Git provider and choose the repo.
4. Set build command to `npm run build` and publish directory to `dist`.
5. Deploy.

## Quick drag-and-drop (Netlify)

You can also build locally (`npm run build`) and drag the `dist/` folder into Netlify's drag-and-drop deploy area.

## Replacing images

Replace the image `src` values in `src/App.jsx` with your own hosted images (or the Unsplash/Pexels links provided earlier).

## License

Feel free to use and modify this template.
